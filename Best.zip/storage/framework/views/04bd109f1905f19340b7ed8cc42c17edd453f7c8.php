<div class="container py-5 col-12 bg-dark"  >
          <div class="row">
            <div class="col-12 col-md">
              <h5>ALL tronica</h5>
              <small class="d-block mb-3 text-muted">&copy;2020</small>
            </div>
            <div class="col-6 col-md">
              <h5>Features</h5>
              <ul class="list-unstyled text-small">
                <li><a class="text-muted" href="#">Cra 96j No 23a-55</a></li>
                <li><a class="text-muted" href="#">Bogotá D.C.</a></li>
                <li><a class="text-muted" href="#">+57 301 777 9956</a></li>
                <li><a class="text-muted" href="#">soluthecyopal@gmail.com</a></li>

              </ul>
            </div>
            <div class="col-6 col-md">
              <h5>Rutas</h5>
              <ul class="list-unstyled text-small">
                <li><a class="text-muted" href="#">Automatizacion</a></li>
                <li><a class="text-muted" href="#">Productos</a></li>
               
              </ul>
            </div>
          
            <div class="col-6 col-md">
              <h5>Siguenos</h5>
              <ul class="list-unstyled text-small">
                <li><a class="text-muted" href="#">Facebook</a></li>
                <li><a class="text-muted" href="#">Instagram</a></li>
               
              </ul>
            </div>
          </div>
        </div>