<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<div id="breadcrumb"> <a href="<?php echo e(url('/admin')); ?>" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="<?php echo e(route('product.index')); ?>">Products</a> <a href="#" class="current">Edit Product</a> </div>
<div class="container-fluid">
    <?php if(Session::has('message')): ?>
    <div class="alert alert-success text-center" role="alert">
        <strong>Well done! &nbsp;</strong><?php echo e(Session::get('message')); ?>

    </div>
    <?php endif; ?>
    <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
            <h5>Add New Products</h5>
        </div>
        <div class="widget-content nopadding">
            <form action="<?php echo e(route('blog.update',$edit_blog->id)); ?>" method="post" class="form-horizontal" enctype="multipart/form-data">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <?php echo e(method_field("PUT")); ?>



                <div class="control-group">
                    <label for="nombre" class="control-label">titulo</label>
                    <div class="controls">
                        <input type="text" name="nombre" id="nombre" class="form-control" value="<?php echo e($edit_blog->nombre); ?>" title="" required="required" style="width: 400px;">
                        
                    </div>
                </div>
            
                <div class="control-group">
                    <label for="contenido" class="control-label">Contenido</label>
                    <div class="controls">
                        <textarea class="textarea_editor span12" name="contenido" id="contenido" rows="6" placeholder="Contenido del post " style="width: 580px;"><?php echo e($edit_blog->contenido); ?></textarea>
                        <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                    </div>
                </div>
              
                <div class="control-group">
                    <label class="control-label">Imagen</label>
                    <div class="controls">
                        <input type="file" name="imagen" id="imagen" />
                        <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                        <?php if($edit_blog->imagen!=''): ?>
                        &nbsp;&nbsp;&nbsp;
                        <a href="javascript:" rel="<?php echo e($edit_blog->id); ?>" rel1="delete-image" class="btn btn-danger btn-mini deleteRecord">Borrar imagen</a>
                        <img src="<?php echo e(url('products/small/',$edit_blog->imagen)); ?>" width="35" alt="">
                        <?php endif; ?>
                    </div>
                </div>
                <div class="control-group">
                    <label for="" class="control-label"></label>
                    <div class="controls">
                        <button type="submit" class="btn btn-success">Edit post</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>