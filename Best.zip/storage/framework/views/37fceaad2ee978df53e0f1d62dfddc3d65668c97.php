<?php $__env->startSection('title','Detalles'); ?>
<?php $__env->startSection('slider'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<br>
<br>

<div class="container">
    <div class="row">
        <div class="col-sm-3">
            <?php echo $__env->make('frontEnd.layouts.category_menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-sm-9 padding-right">
            <?php if(Session::has('message')): ?>
            <div class="alert alert-success text-center" role="alert">
                <?php echo e(Session::get('message')); ?>

            </div>
            <?php endif; ?>
            <div class="product-details">
                <!--product-details-->

                <div class="col-sm-5">
                    <div class="easyzoom easyzoom--overlay easyzoom--with-thumbnails">
                        <a href="<?php echo e(url('products/large',$detail_product->image)); ?>">
                            <img src="<?php echo e(url('products/small',$detail_product->image)); ?>" alt="" id="dynamicImage" />
                        </a>
                    </div>

                    <ul class="thumbnails" style="margin-left: -10px;">
                        <li>
                            <?php $__currentLoopData = $imagesGalleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagesGallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(url('products/large',$imagesGallery->image)); ?>" data-standard="<?php echo e(url('products/small',$imagesGallery->image)); ?>">
                                <img src="<?php echo e(url('products/small',$imagesGallery->image)); ?>" alt="" width="75" style="padding: 8px;">
                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </li>
                    </ul>
                </div>
                <div class="col-sm-7">
                    <form action="<?php echo e(route('addToCart')); ?>" method="post" role="form">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <input type="hidden" name="products_id" value="<?php echo e($detail_product->id); ?>">
                        <input type="hidden" name="product_name" value="<?php echo e($detail_product->p_name); ?>">
                        <input type="hidden" name="product_code" value="<?php echo e($detail_product->p_code); ?>">
                        <input type="hidden" name="product_color" value="<?php echo e($detail_product->p_color); ?>">
                        <input type="hidden" name="price" value="<?php echo e($detail_product->price); ?>" id="dynamicPriceInput">
                        <div class="product-information">
                            <!--/product-information
                        <img src="<?php echo e(asset('frontEnd/images/product-details/new.jpg')); ?>" class="newarrival" alt="" />-->
                            <h2 style="color:#464342 ; font-size:30px;"><?php echo e($detail_product->p_name); ?></h2>


                            <span>
                                <span style="color:#710000; font-size:20px;" id="dynamic_price"> $<?php echo e($detail_product->price); ?></span>
                                <br>
                                <label>Cantidad:</label>
                                <input type="text" name="quantity" value="1" id="inputStock" />
                                <br>

                                <p>En stock: <?php echo e($detail_product->p_color); ?></p>
                                <?php if($detail_product->p_color>0): ?>
                                <button type="submit" class="btn btn-primary" style="font-size: medium;margin:0%;" id="buttonAddToCart">
                                    <i class="fa fa-shopping-cart"></i>
                                    Comprar
                                </button>
                                <?php endif; ?>
                            </span>
                            <p style="margin:0%;"><b>Condicion:</b>
                                <?php if($detail_product->p_color>0): ?>
                                <span id="availableStock" style="color: green;">En Stock</span>
                                <?php else: ?>
                                <span id="availableStock" style="color: red;">fuera de Stock</span>
                                <?php endif; ?>
                            </p>
                            <p style="margin:0%;"><b>Condicion:</b> Nuevo</p>

                        </div>
                        <!--/product-information-->
                    </form>

                </div>
            </div>
            <!--/product-details-->
            <nav>
                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                    <a class=" nav-link bgazo " id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true" style="color:white; font-size:medium;">Descripcion</a>
                    <a class=" nav-link bgazo " id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false" style=" color:white; font-size:medium;">Detalles del producto</a>
                    <a class=" nav-link bgazo " id="nav-contact-tab" data-toggle="tab" href="#nav-contact" role="tab" aria-controls="nav-contact" aria-selected="false" style=" color:white; font-size:medium;">Documentacion</a>
                </div>
            </nav>
            <div class="tab-content" id="nav-tabContent">
                <div class="tab-pane active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                    <br>
                    <h3>Descripcion</h3>
                    <p class="parrafos" style="font-weight: 50px;"> <?php echo e($detail_product->description); ?></p>
                </div>
                <div class="tab-pane " id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                    <br>
                    <p class="parrafos">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Excepturi aspernatur harum possimus enim nemo praesentium consequuntur veniam ratione nobis iste aperiam eaque suscipit, ullam ea soluta impedit repudiandae nulla saepe!</p>

                </div>
                <div class="tab-pane " id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
                    <br>
                    <p class="parrafos">
                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rerum accusantium sit nihil voluptate reprehenderit officia! Ad modi ratione atque iste, exercitationem est eos ducimus dolorum dignissimos placeat neque nisi numquam?
                    </p>
                </div>
            </div>


            <br>
            <br>
            <br>
            <div class="recommended_items">
                <!--recommended_items-->
                <h2 class="titulo clazo">Productos recomendados</h2>

                <div id="recommended-item-carousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner">
                        <?php $countChunk = 0; ?>
                        <?php $__currentLoopData = $relateProducts->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $countChunk++; ?>
                        <div class="item<?php if ($countChunk == 1) {
                                            echo ' active';
                                        } ?>">
                            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-sm-3 ">
                                <div class="product-image-wrapper">
                                    <div class="single-products">
                                        <div class="productinfo ">
                                            <a href="<?php echo e(url('/product-detail',$item->id)); ?>"> <img src="<?php echo e(url('/products/small',$item->image)); ?>" alt="" style="width: 150px;" /></a>
                                            <h3 style="color: #710000" style="font-weight: 100;"><?php echo e($item->p_name); ?></h3>
                                            <p style="margin: 0px; text-align: justify; font-size:12px;"><?php echo substr($item->description,0,100); ?>...</p>
                                            <p class="clcaf" style=" font-size:15px; font-weight: 700;">$<?php echo e($item->price); ?></p>
                                            <p style="color: green ; ">En stock: <?php echo e($item->p_color); ?></p>
                                            <p><a href="<?php echo e(url('/product-detail',$item->id)); ?>" class="clcaf"><i class="far fa-eye"></i></a>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
            </div>
            <!--/recommended_items-->

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>