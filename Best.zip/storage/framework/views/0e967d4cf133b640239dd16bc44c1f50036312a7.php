<?php $__env->startSection('title','Lista de Productos'); ?>
<?php $__env->startSection('slider'); ?>

<?php $__env->startSection('content'); ?>
<br>
<br>
<!--
<form action="<?php echo e(url('/list-products')); ?>" method="get" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>

<div class="row">
<div class="input-group input-group-lg col-sm-4" ></div>
<div class="input-group input-group-lg col-sm-4" >
<input class="form-control" type="text" name ="search2" id= "busdescripcion" value="" placeholder="  Buscar...">
<div class="input-group-append">
    <button class="carrito botonbuscar" type="submit" value="Buscar"><i class="fas fa-search"></i></button>
  </div>

  </div>
</div>
</form> -->
<br>
<div class="container">
    <div class="row">
        <div class="col-sm-3">
            <?php echo $__env->make('frontEnd.layouts.category_menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-sm-9 padding-right">
            <div class="titulo clcaf">
                <!--features_items-->

                <?php
                if ($byCate != "") {
                    $products = $list_product;
                    echo '<h2 class="title text-center">Categoria ' . $byCate->name . '</h2>';
                } else {
                    echo '<h2 class="titulo clazo"> Lista de Productos</h2>';
                }
                ?>

                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($product->category->status==1): ?>
                <div class="cajaproducto col-sm-3 col-5 hvr-wobble-horizontal" style="height: 350px;">
                    <div class="product-image-wrapper">
                        <div class="single-products">
                            <div class="productinfo titulo clazo">
                                <a href="<?php echo e(url('/product-detail',$product->id)); ?>"><img src="<?php echo e(url('products/small/',$product->image)); ?>" alt="" /></a>
                                <h2 class="clazo"> <?php echo e($product->p_name); ?>

                                    <h2>
                                        <p style="color: #5d615e;font-size:10px;text-align:justify"><?php echo substr($product->description,0,150); ?>...</p>
                                        <p class="clcaf">$<?php echo e($product->price); ?></p>
                                        <p style="color: green;"><?php echo e($product->p_color); ?> disponibles </p>
                                        <a href="<?php echo e(url('/product-detail',$product->id)); ?>" class="clcaf"><i class="far fa-eye"></i></a>
                            </div>
                        </div>

                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
            <!--features_items-->
        </div>
    </div>
</div>
<br>
<br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>