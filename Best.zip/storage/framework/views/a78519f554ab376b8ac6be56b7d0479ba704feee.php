<header id="header"><!--header-->
    <div class="header_top"><!--header_top-->
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <div class="contactinfo">
                        <ul class="nav nav-pills">
                        <li><a href="#" style="font-size: 15px;"> ALL TRONICA</a></li>
                            <li><a href="#"><i class="fa fa-phone"></i>3017779956</a></li>
                            <li><a href="#"><i class="fa fa-envelope"></i> example@gmail.com</a></li>
                            
                        </ul>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class=" social-icons pull-right ">
                        <ul class=" row ">
                            <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div><!--/header_top-->

   
    
    <nav class="navbar  navbar-expand-lg navbar-light bg-custom" >
     <div class="container text-center" style="font-size:12px;">
       <a class="navbar-brand logotext" href="<?php echo e(url('/')); ?>" style="font-size: 15px;"> <span style="color:#591E23 ;">ALL</span> TRONICA</a>

       <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
       </button>

       <div class="collapse navbar-collapse" id="navbarSupportedContent">
         
            <ul class="navbar-nav mr-auto">
              
              <li class="nav-item active">
              
                <a class="nav-link" href="<?php echo e(url('/')); ?>">INICIO</a>
                
               
              </li>
              <li class="nav-item active">
              
              
              <a class="nav-link" href="<?php echo e(url('/list-products')); ?>">PRODUCTOS</a>
             
            </li>
            <li class="nav-item active">
              
              
              <a class="nav-link" href="<?php echo e(url('/contactenos')); ?>">CONTACTENOS</a>
             
            </li>
              
            </ul>
        

             <ul class="navbar-nav ml-auto  " >
                 
                   <li class="nav-item mr-lg-3 space_login" >
                       <a class="btn btn-ingreso  " href="<?php echo e(url('/viewcart')); ?>" style="font-size: 15px;"><i class="fa fa-shopping-cart"></i> Carrito</a></li>
                            <?php if(Auth::check()): ?>
                                <li class="nav-item mr-lg-3 space_login">
                                    <a class="btn btn-ingreso  " href="<?php echo e(url('/myaccount')); ?>" style="font-size: 15px;"><i class="fa fa-user"></i> Mi cuenta</a></li>
                                <li class="nav-item mr-lg-3 space_login">
                                    <a class="btn btn-ingreso " href="<?php echo e(url('/logout')); ?>" style="font-size: 15px;"><i class="fa fa-lock" style="font-size: 15px;"></i> Salir </a>
                                </li>
                            <?php else: ?>
                                <li class="nav-item mr-lg-3 space_login">
                                    <a class="btn btn-ingreso" href="<?php echo e(url('/login_page')); ?>" style="font-size: 15px;"><i class="fa fa-lock"></i> Login</a></li>
                            <?php endif; ?>
                                
              </ul>



         
       </div>
     </div> 
    
    </nav>


</header><!--/header-->