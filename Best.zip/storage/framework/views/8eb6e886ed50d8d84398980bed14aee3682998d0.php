<section id="slider"><!--slider-->
    <div class="container">
        
    </div>
</section><!--/slider-->