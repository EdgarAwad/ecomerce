<?php $__env->startSection('title','Review Order Page'); ?>
<?php $__env->startSection('slider'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3 class="text-center">TU PEDIDO HA SIDO RECIBIDO</h3>
        <p class="text-center">Gracias por comprar con nosotros</p>
        <p class="text-center">Te contactaremos al correo:(<b><?php echo e($user_order->users_email); ?></b>) o telefono: (<b><?php echo e($user_order->mobile); ?></b>) para cordinar tiempos de entrega.</p>
    </div>
    <div style="margin-bottom: 20px;"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>