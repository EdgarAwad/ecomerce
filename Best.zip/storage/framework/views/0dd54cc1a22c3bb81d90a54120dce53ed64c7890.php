<?php $__env->startSection('title','Alltronica'); ?>

<?php $__env->startSection('content'); ?>

    <section>
    <main role="main">    
<div class="jumbotron">
  <div class="container">
    <h1 class="display-3">All tronica</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod, accusamus voluptas culpa amet, odit quos dignissimos voluptate consectetur, ad aliquid illum nihil. Architecto fugit explicabo illo! Corporis rerum voluptatem labore.</p>
    <p><a class="btn btn-primary" href="#" role="button">Nosotros &raquo;</a></p>
  </div>
</div>

<div class="container marketing" style="width: 100%;">

      
<div class="row">
  <div class="col-lg-3" style="text-align: center;">
    <svg class="bd-placeholder-img rounded-circle" width="140" height="140" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: 140x140"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text></svg>
    <h2>servicio 1</h2>
    <p>servicio 1</p>
    <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
  </div>
  <div class="col-lg-3" style="text-align: center;">
    <svg class="bd-placeholder-img rounded-circle" width="140" height="140" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: 140x140"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text></svg>
    <h2>servicio 2</h2>
    <p>servicio 2</p>
    <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
  </div>
  <div class="col-lg-3" style="text-align: center;">
    <svg class="bd-placeholder-img rounded-circle" width="140" height="140" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: 140x140"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text></svg>
    <h2>servicio 3</style></h2>
    <p>servicio 3</p>
    <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
  </div>
  <div class="col-lg-3" style="text-align: center;">
    <svg class="bd-placeholder-img rounded-circle" width="140" height="140" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="xMidYMid slice" focusable="false" role="img" aria-label="Placeholder: 140x140"><title>Placeholder</title><rect width="100%" height="100%" fill="#777"/><text x="50%" y="50%" fill="#777" dy=".3em">140x140</text></svg>
    <h2>servicio 4</h2>
    <p>servicio 4</p>
    <p><a class="btn btn-primary" href="#" role="button">View details &raquo;</a></p>
  </div>
</div>
</div>
<!--fin de ser5vicio-->  


<br>
<br>



       


    <!--inicio de card--> 
    <div class="col-md-10" style=" margin: 0% 5% 0% 5%;">
   <div class="card mb-3" >
    <div class="row no-gutters">
      <div class="col-md-4">
        <img src="<?php echo e(asset('img/gria.jpg')); ?>" class="card-img" alt="..." width="100" height="200" >
      </div>
      <div class="col-md-8">
        <div class="card-body">
          <h5 class="card-title">Card title</h5>
          <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
          <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
        </div>
      </div>
    </div>
  </div>
  </div>
  <!--fin de card-->
  <br>
  <br>

        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                  
                </div>

                <div class="col-sm-12 padding-right">
                    <div class="features_items"><!--features_items-->
                        <h2 class="title text-center">Ultimos productos</h2>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($product->category->status==1): ?>
                            <div class="col-sm-3">
                                <div class="product-image-wrapper">
                                <div class="single-products">
                                    <div class="productinfo text-center">
                                        <a href="<?php echo e(url('/product-detail',$product->id)); ?>"><img src="<?php echo e(url('products/small/',$product->image)); ?>" alt="" /></a>
                                        <h2>$ <?php echo e($product->price); ?></h2>
                                        <p><?php echo e($product->p_name); ?></p>
                                        <a href="<?php echo e(url('/product-detail',$product->id)); ?>" class="btn btn-default add-to-cart">Mas</a>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div><!--features_items-->

                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontEnd.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>