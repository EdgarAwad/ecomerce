<div class="container py-5 col-12 bg-dark"  >
          <div class="row">
            <div class="col-4 col-md">
              <h5 class="pie medium linea" >Informacion</h5>
              <ul class="list-unstyled text-small">
              <li class="pie footerpequeño"><a class="pie" href="#"><i class="far fa-address-card"></i>  Servicios</a></li>
                <li class="pie footerpequeño"><a class="pie" href="#"><i class="fas fa-microchip"></i>  Productos</a></li>
              <li class="pie footerpequeño"><a class="pie" href="#"><i class="fas fa-user-shield"></i>  Quienes somos</a></li>
                <li class="pie footerpequeño"><a class="pie" href="#"><i class="fas fa-cart-plus"></i>  Como comprar</a></li>
                </ul>
              </div>

            <div class="col-4 col-md">
              <h5 class="pie medium linea" >Atencion al cliente</h5>
              <ul class="list-unstyled text-small">
                <li class="pie footerpequeño"><a class="pie" href="#"><i class="fas fa-map-marker-alt"></i>  Cra 96j No 23a-55</a></li>
                <li class="pie footerpequeño" ><a class="pie" href="#"><i class="fas fa-phone"></i>  301000000</a></li>
               
              </ul>
            </div>
          
            <div class="col-4 col-md">
              <h5 class="pie  medium linea"  >Horarios</h5>
              <ul class="list-unstyled text-small">
                <li class="pie footerpequeño"><a class="pie" href="#">lunes a viernes 7:00AM a 5:00PM</a></li>
               
               
              </ul>
            </div>
          </div>
          <div class="row">
            <div></div>
          <div class="col-lg-4 col-md-12 col-12 " >
            <div>
            <img src="<?php echo e(asset('img/Banner.png')); ?>" alt="" width="250px">
            </div>
          </div> 
          <div class="col-lg-2 col-md-12 col-12 " style="color:gray;">
            <h5 class="pie medium" style="color:gray;" >Alltronica  </h5>
            <p style="margin: 0px;">Todos los derecos reservados</p>
            <p style="margin: 0px;">2020</p>
          </div>
          <div class="col-3 ">

          </div>
          <div class="col-lg-2 col-md-12 col-12 " >
            <div  style="text-align:left;">
            <p style="color:gray;"> siguenos en nuestras redes</p>
            
            <div>
            <i class="fab fa-facebook-f redes"></i><i class="fab fa-instagram redes"></i> <i class="fab fa-whatsapp redes"></i>
           </div>
          </div>
          </div>

        </div>