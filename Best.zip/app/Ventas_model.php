<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ventas_model extends Model
{
    //
}
