@extends('frontEnd.layouts.master')
@section('title','servicios')
@section('slider')
@section('content')
<section>
      
      <div class="jumbotron " style=" background: url('products/small/automatizacion.jpg') top center fixed;
          background-size: cover; padding: 0%; margin: 0%;" >
        <div class="container fondo" >
          <h1 class="animate__animated animate__backInLeft display-3 " style="color: white;">Automatizacion de procesos</h1>
          <p class="animate__animated animate__backInRight" style="color: white;">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Voluptate commodi distinctio eveniet culpa tenetur libero nulla dolores, nobis hic, accusantium atque rerum eligendi ipsam exercitationem esse nemo enim suscipit incidunt. .</p>
          <!--  <p><a class="btn btn-primary" href="#" role="button">Nosotros &raquo;</a></p>-->
        </div>
      </div>
</section>

@endsection