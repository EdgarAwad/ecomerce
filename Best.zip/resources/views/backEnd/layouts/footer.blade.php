<div class="row-fluid">
    <div id="footer" class="span12"> ALLtronik 2020 Copyright©. <br> Derechos reservados.</div>
</div>